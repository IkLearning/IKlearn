<?php 

require_once('libs/Bootstrap.php');

new Bootstrap;