<?php
/**
 * Configuration for website
 *
 */
define('APP_NAME',"banchamp");  
define('HTTP_SERVER', 'http://Iklearn.me:88/'); 
define('SITE_NAME', 'http://Iklearn.me:88/');
define('ROOT',$_SERVER['DOCUMENT_ROOT'].APP_NAME);

/**
 * Configuration for database connection
 *
 */

define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "db_banhang");


