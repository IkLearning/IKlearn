<div class="col-lg-3">
    <h1 class="my-4">Shop LNL</h1>
    <ul class="nav flex-column">
    <li><a class="nav-link active" href="#">Menu 1</a></li>
    <li><a class="nav-link active" href="#">Menu 2</a></li>
    <li><a class="nav-link active" href="#">Menu 3</a></li>
    <li><a class="nav-link active" href="#">Menu 4</a></li>
    </ul>
</div>